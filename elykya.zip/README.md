elk
===

a demo app to emulate a static mobile website
